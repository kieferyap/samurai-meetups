# Samurai Meetups Website

Samurai Meetups is a non-profit organization which was launched with the strong desire to serve people who have always loved the Japanese culture but has never had the chance to experience it. For more information, visit the following [website](http://www.meetup.com/en-US/https-www-facebook-com-samuraimeetups/)

-----------------------

## Project Specification Overview:
- **Language:** PHP 5.5.12
- **Framework:** Yii 2.0.9
- **Database:** MySQL 5.7.13