$(document).ready(
	function() {
		// alert("Hello!");
		// test();
	}
);

function test() {
	alert("Test");
}